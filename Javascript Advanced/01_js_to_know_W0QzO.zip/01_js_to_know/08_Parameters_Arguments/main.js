var yearOfBirth = 1990;

function calAge(year) {
  return 2021 - year;
}

var age = calAge(yearOfBirth);